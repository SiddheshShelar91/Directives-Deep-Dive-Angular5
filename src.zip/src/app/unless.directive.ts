import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[appUnless]'
})
export class UnlessDirective {

  @Input() set appUnless(condition : boolean) { // whenever some input parameter here changes I want to execute a method and therefore I can implement a set keyword
    if(!condition){
       this.vcRef.createEmbeddedView(this.templateRef);

      //  TemplateRef says: "Don't render me, but you can embed my content somewhere else."

      //  ViewContainerRef says: "I mark the position after which new content may be inserted."
    } else {
       this.vcRef.clear(); // remove everything from this place in the DOM
    }
  }

// getters / setters can be used as a property outside but written as a method inside. 
// Here it says, something will be set to the appUnless property in the template, so when its set, 
// with @Input grab them and use it inside the same, make modifications and spit the modified value out. 
// The templateRef grabs the "what needs to be inserted dynamically" and the ViewContainerRef tells 
// where it should be inserted based on condition.So from the example perspective, when the condition is true, 
// then add something, or if not, clear the template from the container.

  constructor(private templateRef : TemplateRef<any>, private vcRef: ViewContainerRef) {
    console.log(templateRef.elementRef.nativeElement === vcRef.element.nativeElement,'abc');
    console.log(templateRef.elementRef.nativeElement,'templateRef.elementRef.nativeElement');
    console.log(vcRef.element.nativeElement,'vcRef.element.nativeElement');
    
    
   }

}
