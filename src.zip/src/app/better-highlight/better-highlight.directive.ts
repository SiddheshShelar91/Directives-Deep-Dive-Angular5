import { Directive, Renderer2, OnInit, ElementRef, HostListener, HostBinding, Input } from '@angular/core';

@Directive({
  selector: '[appBetterHighlight]'
})
export class BetterHighlightDirective implements OnInit {

  @Input() defaultColor : string = 'transparent';
  @Input('appBetterHighlight') highlightColor : string = 'blue';

  @HostBinding('style.backgroundColor') backgroundColor : string;
  // @HostBinding('style.backgroundColor') backgroundColor : string = this.defaultColor;
  // @HostBinding('style.backgroundColor') backgroundColor : string = 'transparent'; // set initial value to transparent color
   
  // HostBinding is to bind a property upon a condition. Upon some condition, you need to add/remove classes or 
  // other proeprties to elements

  // Any DOM property can be conditionally bound with HostBinding. With HostListener, you can listen to any event 
  // happening in UI and handle them inside directive. ( clicks, hovers etc )
  constructor(private elRef: ElementRef, private renderer: Renderer2) { }

  ngOnInit() {
     this.backgroundColor = this.defaultColor; // to get default color on page loads [defaultColor]="'yellow'"
    // this.renderer.setStyle(this.elRef.nativeElement,'background-color','blue');
  }

  @HostListener('mouseenter') mouseover(eventData: Event) {  // this can be triggerred whenever some event occurs and that event is specified here as an argument 
    // that is my HostListener targeting event name 'mouseenter'.
    // @HostListener('mouseenter', ['$event']) mouseover(eventData: Event) {

    console.log(eventData, "eventData-mouseover");

    // this.renderer.setStyle(this.elRef.nativeElement, 'background-color', 'blue');
    this.renderer.setStyle(this.elRef.nativeElement, 'color', 'white');
    // this.backgroundColor = 'blue';
    this.backgroundColor = this.highlightColor; // binding to directive properties
  }

  // @HostListener('mouseleave') mouseleave(eventData : Event){ 
  @HostListener('mouseleave', ['$event']) mouseleave(eventData: Event) {

    console.log(eventData, "eventData-mouseleave");

    // this.renderer.setStyle(this.elRef.nativeElement, 'background-color', 'transparent');
    this.renderer.setStyle(this.elRef.nativeElement, 'color', 'black');
    // this.backgroundColor = "transparent";
    this.backgroundColor = this.defaultColor; // binding to directive properties
  }

  //Q. In which scenarios it's better approach to add and listen events on directives? 

  //A. If you have a scenario where you need to reuse them across multiple places. Eg: on mousehover, 
  // the element should have a box shadow. This can be a directive and the same directive can be attaached 
  // on card elements, quotes etc.  You can use the HostBinding and HostListener
}
