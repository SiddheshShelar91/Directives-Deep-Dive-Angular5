import { BetterHighlightDirective } from './better-highlight.directive';

describe('BetterHighlightDirective', () => {
  it('should create an instance', () => {
    const directive = new BetterHighlightDirective();
    expect(directive).toBeTruthy();
  });
});
