import { Directive, ElementRef, OnInit } from "@angular/core";

// we need to pass an object to the decorator to configure this directive.
@Directive({
 selector : '[appBasicHighlight]'
})

export class BasicHighlightDirective implements OnInit{
  
    constructor(private elementRef: ElementRef){
    }

    ngOnInit(){
        this.elementRef.nativeElement.style.backgroundColor = "green"

        // With elementRef  you get a reference to the element in the template on which the directive is placed. 
        // With nativeElement  you get access to the native DOM element belonging to this element in the template, 
        // and then you style its background exactly like you would do it with normal JavaScript.

        //Q. While using ngClass, square brackets are used. What's the difference between using square brackets for 
        // [ngClass] and not using those for appBasicHighlight ?

        //A:- When we use [ ] , we say, here is something whose value is something which we bind dynamically. 
        // So for [ngClass], its usually, "apply this class when the condition is something" scenarios. 
        // With directives, you get more flexibility of grabbing not just class, but any property on element, 
        // may it be class, style, or any other attribute and use @HostBinding to bind the same based on a 
        // condition inside the directive. We can also listen to events too.
    }
    
}